numero = 55
var = 0
continuar = 1
uno = 1
while continuar==1:
    var = int(input())
    if var==numero:
        continuar = 0
        print("El numero ingresado es el correcto")
    if var>numero:
        print("El numero ingresado es mayor")
    if var<numero:
        print("EL numero ingresado es menor")
